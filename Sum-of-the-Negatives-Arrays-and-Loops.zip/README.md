# Instructions

Write a method which takes in an array of integers and returns the sum of only the negative integers in the array.

**Examples**

```js
sumOfNegatives([3, -1, -9, 2]) ==> -10
sumOfNegatives([4, 5, 1]) ==> 0
```
