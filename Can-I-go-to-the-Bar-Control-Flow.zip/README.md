# Instructions

Write a function that takes in a number argument and returns a boolean if the person is of age to enter a bar or not.

```js
enterTheBar(21) ==> True
enterTheBar(19) ==> False
```